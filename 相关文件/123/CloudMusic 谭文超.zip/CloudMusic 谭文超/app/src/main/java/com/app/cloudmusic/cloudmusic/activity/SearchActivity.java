package com.app.cloudmusic.cloudmusic.activity;

import android.app.Activity;
import android.os.Bundle;

import com.app.cloudmusic.cloudmusic.R;

/**
 * Created by Administrator on 2016/10/9 0009.
 */
public class SearchActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    }
}
