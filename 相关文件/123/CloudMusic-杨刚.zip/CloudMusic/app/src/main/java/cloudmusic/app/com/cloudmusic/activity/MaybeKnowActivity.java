package cloudmusic.app.com.cloudmusic.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import cloudmusic.app.com.cloudmusic.R;

public class MaybeKnowActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maybe_know);
    }
}
