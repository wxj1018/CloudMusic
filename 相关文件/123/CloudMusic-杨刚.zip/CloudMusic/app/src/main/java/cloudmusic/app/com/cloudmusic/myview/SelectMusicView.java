package cloudmusic.app.com.cloudmusic.myview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.EditText;

/**
 * Created by yg on 2016/10/23.
 */
public class SelectMusicView extends EditText {
    public SelectMusicView(Context context) {
        super(context);
    }

    public SelectMusicView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SelectMusicView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
