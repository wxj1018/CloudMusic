package cloudmusic.app.com.cloudmusic;

import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.ArrayList;

import cloudmusic.app.com.cloudmusic.adapter.VPAdapter;
import cloudmusic.app.com.cloudmusic.fragment.MainMusicFragment;
import cloudmusic.app.com.cloudmusic.fragment.MyFriendFragment;
import cloudmusic.app.com.cloudmusic.fragment.MyMusicFragment;

public class MainActivity extends AppCompatActivity implements ViewPager.OnPageChangeListener,RadioGroup.OnCheckedChangeListener{
    private ViewPager vp;
    private ArrayList<Fragment> list = new ArrayList<>();
    private RadioButton rbtnMain, rbtnMusic, rbtnFriend;
    private RadioGroup rg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        rbtnMain= (RadioButton) findViewById(R.id.rbtn_m_main);
        rbtnMusic= (RadioButton) findViewById(R.id.rbtn_s_main);
        rbtnFriend= (RadioButton) findViewById(R.id.rbtn_f_main);
        rg= (RadioGroup) findViewById(R.id.rg_main);
        rg.setOnCheckedChangeListener(this);


        vp = (ViewPager) findViewById(R.id.vp_main);
        list.add(new MainMusicFragment());
        list.add(new MyMusicFragment());
        list.add(new MyFriendFragment());
        VPAdapter adapter = new VPAdapter(list, getSupportFragmentManager());
        vp.setAdapter(adapter);
        vp.setOnPageChangeListener(this);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId){
            case R.id.rbtn_m_main:
                vp.setCurrentItem(0);
                break;
            case R.id.rbtn_s_main:
                vp.setCurrentItem(1);
                break;
            case R.id.rbtn_f_main:
                vp.setCurrentItem(2);
                break;
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {
        if (state==2){
            switch (vp.getCurrentItem()){
                case 0:
                    rbtnMain.setChecked(true);
                    break;
                case 1:
                    rbtnMusic.setChecked(true);
                    break;
                case 2:
                    rbtnFriend.setChecked(true);
                    break;
            }
        }
    }
}
