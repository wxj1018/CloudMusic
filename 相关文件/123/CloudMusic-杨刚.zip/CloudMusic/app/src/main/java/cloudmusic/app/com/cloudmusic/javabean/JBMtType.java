package cloudmusic.app.com.cloudmusic.javabean;

/**
 * Created by yg on 2016/10/21.
 */
public class JBMtType {
    private int id;
    private String name;

    public JBMtType(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
